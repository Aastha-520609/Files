package com.paymentservice.payment_service.Controller;

import com.paymentservice.payment_service.DTO.PaymentRequest;
import com.paymentservice.payment_service.DTO.PaymentResponse;
import com.paymentservice.payment_service.Entity.Payment;
import com.paymentservice.payment_service.Service.PaymentService;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/payments")
public class PaymentController {

    private final PaymentService paymentService;

    public PaymentController(PaymentService paymentService) {
        this.paymentService = paymentService;
    }
    
    @PostMapping("/process")
    public ResponseEntity<PaymentResponse> processPayment(
            @RequestBody PaymentRequest paymentRequest,
            @RequestHeader(value = "X-User-Role", required = false) String userRole) {

        // Log the received role for debugging
        System.out.println("Received X-User-Role in payment-service: " + userRole);

        // Optionally enforce role-based validation
        if (userRole == null || !userRole.equalsIgnoreCase("USER")) {
            return ResponseEntity.status(403).body(new PaymentResponse(null, "Access Denied"));
        }

        PaymentResponse processedPayment = paymentService.processPayment(paymentRequest.getBookingId());
        return ResponseEntity.ok(processedPayment);
    }

//    @GetMapping("/{transactionId}")
//    public ResponseEntity<Payment> getPaymentByTransactionId(@PathVariable String transactionId) {
//        return ResponseEntity.ok(paymentService.getPaymentByTransactionId(transactionId));
//    }
//
//    @GetMapping("/booking/{bookingId}")
//    public ResponseEntity<Payment> getPaymentByBookingId(@PathVariable Long bookingId) {
//        return ResponseEntity.ok(paymentService.getPaymentByBookingId(bookingId));
//    }
    
    @PostMapping("/simulate-success/{bookingId}")
    public ResponseEntity<?> simulatePaymentSuccess(@PathVariable Long bookingId) {
        // 1. Mark payment as SUCCESS for this bookingId
        Payment payment = paymentRepository.findByBookingId(bookingId)
            .orElseThrow(() -> new RuntimeException("Payment not found"));
        payment.setPaymentStatus("SUCCESS");
        paymentRepository.save(payment);

        // 2. Call booking-service to confirm booking and reduce seats
        bookingClient.confirmBooking(bookingId);

        return ResponseEntity.ok("Payment simulated as successful and booking confirmed.");
    }
}
