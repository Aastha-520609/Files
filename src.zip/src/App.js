import { BrowserRouter as Router, Routes, Route } from "react-router-dom";
import Navbar from "./components/user/Navbar";
import FlightSearch from "./components/user/FlightSearch";
import WhyUs from "./components/user/WhyUs";
import FlightOffers from "./components/user/FlightOffers";
import Footer from "./components/user/Footer";
import Login from "./components/user/Login";
import Signup from "./components/user/Signup";
import AdminDashboard from './components/admin/AdminDashboard';
import FlightResults from "./components/user/FlightResults"; 
import BookingPage from "./components/user/BookingPage";
import PaymentPage from "./components/user/PaymentPage";
import "./App.css";

function App() {
  return (
    <Router>
      <Navbar /> 
      <Routes>
        <Route path="/" element={
          <>
            <FlightSearch />
            <WhyUs />
            <FlightOffers />
            <Footer />
          </>
        } />
        <Route path="/login" element={<Login />} />
        <Route path="/signup" element={<Signup />} />
        <Route path="/admin-dashboard" element={<AdminDashboard />} />
        <Route path="/results" element={<FlightResults />} />
        <Route path="/book" element={<BookingPage />} />
        <Route path="/payment" element={<PaymentPage />} />
      </Routes>
    </Router>
  );
}

export default App;