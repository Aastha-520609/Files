import React from 'react';
import '../../styles/user/Footer.css';

const Footer = () => {
  return (
    <footer className="footer">
      <div className="footer-links">
        <div className="footer-section">
          <h4>Flight Services</h4>
          <ul>
            <li>Book Flights</li>
            <li>Flight Status</li>
            <li>Check-In</li>
            <li>Airlines</li>
          </ul>
        </div>

        <div className="footer-section">
          <h4>Support</h4>
          <ul>
            <li>Contact Us</li>
            <li>FAQs</li>
            <li>Cancellation</li>
            <li>Refund Policy</li>
          </ul>
        </div>

        <div className="footer-section">
          <h4>Company</h4>
          <ul>
            <li>About Us</li>
            <li>Careers</li>
            <li>Terms of Use</li>
            <li>Privacy Policy</li>
          </ul>
        </div>
      </div>

      <div className="footer-bottom">
        <p>© 2025 FlyAway. All rights reserved.</p>
      </div>
    </footer>
  );
};

export default Footer;
