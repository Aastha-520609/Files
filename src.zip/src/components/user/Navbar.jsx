import React from "react";
import "../../styles/user/Navbar.css";
import { FaTags, FaSuitcaseRolling, FaHeadset } from "react-icons/fa";
import { MdFlightTakeoff } from "react-icons/md";
import { useNavigate } from "react-router-dom";

const Navbar = () => {
  const navigate = useNavigate();
  const isLoggedIn = !!localStorage.getItem("token");

  const handleLogout = () => {
    localStorage.removeItem("token");
    localStorage.removeItem("role");
    navigate("/login");
    window.location.reload();
  };

  return (
    <nav className="navbar">
      <div className="navbar-left">
        <MdFlightTakeoff className="logo-icon" />
        <span className="logo-text">bookMyFlight</span>
      </div>
      <div className="navbar-right">
        <div className="nav-item"><FaTags /><span>Offers</span></div>
        <div className="nav-item"><FaSuitcaseRolling /><span>My Trips</span></div>
        <div className="nav-item"><FaHeadset /><span>Support</span></div>
        {isLoggedIn ? (
          <button className="login-button" onClick={handleLogout}>Logout</button>
        ) : (
          <button className="login-button" onClick={() => navigate('/login')}>Log in</button>
        )}
      </div>
    </nav>
  );
};

export default Navbar;