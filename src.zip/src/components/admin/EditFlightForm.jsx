import React, { useState } from "react";

const EditFlightForm = ({ flight, onEdit, onClose }) => {
  const [updated, setUpdated] = useState({ ...flight });

  const handleChange = (e) => {
    setUpdated({ ...updated, [e.target.name]: e.target.value });
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    // Converting price and seatsAvailable to numbers
    onEdit({
      ...updated,
      price: Number(updated.price),
      seatsAvailable: Number(updated.seatsAvailable),
    });
  };

  return (
    <div className="modal">
      <form className="flight-form" onSubmit={handleSubmit}>
        <h3>Edit Flight</h3>
        <input name="airlineName" placeholder="Airline Name" value={updated.airlineName} onChange={handleChange} required />
        <input name="flightNumber" placeholder="Flight Number" value={updated.flightNumber} onChange={handleChange} required />
        <input name="source" placeholder="Source" value={updated.source} onChange={handleChange} required />
        <input name="destination" placeholder="Destination" value={updated.destination} onChange={handleChange} required />
        <input type="date" name="flightDate" value={updated.flightDate} onChange={handleChange} required />
        <input type="time" name="departureTime" value={updated.departureTime} onChange={handleChange} required />
        <input type="time" name="arrivalTime" value={updated.arrivalTime} onChange={handleChange} required />
        <input type="number" name="price" placeholder="Price" value={updated.price} onChange={handleChange} required />
        <input type="number" name="seatsAvailable" placeholder="Seats Available" value={updated.seatsAvailable} onChange={handleChange} required />
        <button type="submit">Save</button>
        <button type="button" onClick={onClose}>Cancel</button>
      </form>
    </div>
  );
};

export default EditFlightForm;